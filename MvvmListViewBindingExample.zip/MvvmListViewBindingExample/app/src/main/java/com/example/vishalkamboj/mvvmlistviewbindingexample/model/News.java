package com.example.vishalkamboj.mvvmlistviewbindingexample.model;

/**
 * Created by vishalkamboj on 04/12/17.
 */

public class News {

    public String header;
    public String desc;

    public News(String header, String desc) {
        this.header = header;
        this.desc = desc;
    }
}



